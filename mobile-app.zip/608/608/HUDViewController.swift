//
//  HUDViewController.swift
//  608
//
//  Created by Enrique Avina on 5/3/19.
//  Copyright © 2019 MakeSquad. All rights reserved.
//

import UIKit
import Alamofire


struct Player {
    var username: String
    var health: Int
    var bullets: Int
    
    var description : String {
        get {
            return "username: \(username)\nhealth: \(health), bullets: \(bullets)"
        }
    }
}

class HUDViewController: UITableViewController {
    
    let nib = UINib(nibName: "CustomCell", bundle: nil)
    
    let url: String = "http://608dev.net/sandbox/sc/moisest/finalProject/request.py"
    var playerData: [String: [Any]] = [String: [Any]]() // String: [Int, Double, Double]
    
    var tablePlayerData: [Player]?
    
    var timer: Timer?
    
    override func viewWillAppear(_ animated: Bool) {
        getAllPlayerData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(nib, forCellReuseIdentifier: "Cell")
        self.tableView.remembersLastFocusedIndexPath = true
        UIView.setAnimationsEnabled(false)
        self.tableView.rowHeight = 200
    
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(HUDViewController.getAllPlayerData), userInfo: nil, repeats: true)
        // timer?.invalidate()
    }
    
    @objc func getAllPlayerData(){
        
        Alamofire.request(url, method: .get, parameters: ["action": "getAll"], encoding: URLEncoding.default).responseJSON { response in
            switch(response.result) {
            case .success(_):
                do {
                    let json = response.result.value as! [String: [Any]]
                    self.tablePlayerData = [Player]()
                    
                    for (key, value) in json {
                        let player: Player = Player(username: key, health: value[0] as? Int ?? -1, bullets: value[1] as? Int ?? -1)
                        self.tablePlayerData?.append(player)
                    }
                    
                    self.reloadWithoutScroll()
//                    self.tableView.reloadDataWithoutScroll()
                }
                
            case .failure(_):
                print("Error message:\(String(describing: response.result.error))")
                break
            }
        }
    }
    
    func reloadWithoutScroll(){
        let contentOffset = self.tableView.contentOffset
        self.tableView.reloadData()
        self.tableView.layoutIfNeeded()
        self.tableView.setContentOffset(contentOffset, animated: false)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! CustomCell
        
        print(tablePlayerData![indexPath.row])
        
        cell.usernameLabel.text = tablePlayerData?[indexPath.row].username
        cell.healthLabel.text = "Health: \(tablePlayerData?[indexPath.row].health ?? 3)"
        cell.bulletsLabel.text = "Bullets: \(tablePlayerData?[indexPath.row].bullets ?? 0)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tablePlayerData?.count ?? 0
    }

}

//
//  CustomCell.swift
//  608
//
//  Created by Enrique Avina on 5/5/19.
//  Copyright © 2019 MakeSquad. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell {
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var healthLabel: UILabel!
    @IBOutlet weak var bulletsLabel: UILabel!
}

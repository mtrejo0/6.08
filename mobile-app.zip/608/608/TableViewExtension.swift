//
//  TableViewExtension.swift
//  608
//
//  Created by Enrique Avina on 5/16/19.
//  Copyright © 2019 MakeSquad. All rights reserved.
//

import Foundation
import UIKit

extension UITableView {
    func reloadWithoutScroll(){
        let offset = contentOffset
        reloadData()
        layoutIfNeeded()
        setContentOffset(offset, animated: false)
    }
}

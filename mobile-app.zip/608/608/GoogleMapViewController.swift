//
//  GoogleMapViewController.swift
//  608
//
//  Created by Enrique Avina on 5/6/19.
//  Copyright © 2019 MakeSquad. All rights reserved.
//

import UIKit
import GoogleMaps
import Alamofire

class GoogleMapViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate {

    var camera: GMSCameraPosition?
    var locationManager: CLLocationManager!
    var reigonSet: Bool = false
    
    var locationDict: [String: CLLocationCoordinate2D] = [String: CLLocationCoordinate2D]()
    static var user: String = "ricc"
    let url: String = "http://608dev.net/sandbox/sc/moisest/finalProject/request.py"
    let headers = ["Content-Type": "application/x-www-form-urlencoded"]
    
    var markers = [String: GMSMarker]()
    
    @IBOutlet weak var mapView: GMSMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        camera = GMSCameraPosition.camera(withLatitude: 54, longitude: -43, zoom: 12.0)
       
        mapView.delegate = self
        mapView.isMyLocationEnabled = true
        
        initLocationServices()
        
//        print("Current user: \(GoogleMapViewController.user)")
    }
    
    func makeMarker(position: CLLocationCoordinate2D, user: String){
        let marker = GMSMarker()
        marker.position = position
        marker.title = user
        marker.map = mapView
        
        markers[user] = marker
    }
    
    func initLocationServices(){
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // Center map on location
        if let location = locations.last{
            if !reigonSet {
               camera = GMSCameraPosition(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude, zoom: 15.0)
                mapView.camera = camera!
                reigonSet = true
            }
            
            let parameters: Parameters = ["user": GoogleMapViewController.user, "action": "gpsUpdate", "lat": location.coordinate.latitude, "lon": location.coordinate.longitude]
            updateLocationRequest(parameters: parameters)
        }
    }
    
    func updateLocationRequest(parameters: Parameters){
        Alamofire.request(url, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: headers).responseJSON { response in
            switch(response.result) {
            case .success(_):
                do {
                    let json = response.result.value as! [String: [Double]]
                    
                    for (user, loc) in json {
                        self.locationDict[user] = CLLocation(latitude: loc[0], longitude: loc[1]).coordinate
                        
                        if user != GoogleMapViewController.user {  // Don't make a marker for yourself
                            if self.markers.keys.contains(user) {
                                self.markers[user]?.position = self.locationDict[user]!
                            } else {
                                self.makeMarker(position: self.locationDict[user]!, user: user)
                            }
                        }
                    }
                }
            case .failure(_):
                print("Error message:\(String(describing: response.result.error))")
                break
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

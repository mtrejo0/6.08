//
//  ViewController.swift
//  608
//
//  Created by Enrique Avina on 4/30/19.
//  Copyright © 2019 MakeSquad. All rights reserved.
//

import UIKit
import CoreLocation
import Alamofire
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    var locationManager: CLLocationManager!
    var locationDict: [String: CLLocationCoordinate2D] = [String: CLLocationCoordinate2D]()
    
    let user: String = "ricc"
    let url: String = "http://608dev.net/sandbox/sc/moisest/finalProject/request.py"
    let headers = ["Content-Type": "application/x-www-form-urlencoded"]
    
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getCurrentLocation()
    }
    
    func getCurrentLocation(){
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // update map focus
        if let location = locations.last{
            let parameters: Parameters = ["user": user, "action": "gpsUpdate", "lat": location.coordinate.latitude, "lon": location.coordinate.longitude]
            updateLocationRequest(parameters: parameters)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error \(error)")
    }
    
    func updateLocationRequest(parameters: Parameters){
        
        Alamofire.request(url, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: headers).responseJSON { response in
            switch(response.result) {
            case .success(_):
                do {
                    let json = response.result.value as! [String: [Double]]
                    for (user, loc) in json {
                        self.locationDict[user] = CLLocation(latitude: loc[0], longitude: loc[1]).coordinate
                        
                        let annotation = MKPointAnnotation()
                        annotation.title = user
                        annotation.coordinate = self.locationDict[user]!
                        self.map.addAnnotation(annotation)
                    }
                print(" ")
                }
            case .failure(_):
                print("Error message:\(String(describing: response.result.error))")
                break
            }
        }
    }
}
